<?php
// Expects $tanks array
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إدارة المخزون والآبار | بتروديزل</title>
    <link href="<?= BASE_URL ?>/css/style.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root {
            --primary: #4361ee;
            --primary-dark: #3f37c9;
            --secondary: #f72585;
            --bg-glass: rgba(255, 255, 255, 0.95);
        }
        body {
            font-family: 'Tajawal', sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
        }
        .glass-card {
            background: var(--bg-glass);
            border-radius: 20px;
            box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.1);
            padding: 2rem;
            margin-bottom: 2rem;
        }
        .tank-card {
            background: white;
            border-radius: 15px;
            padding: 1.5rem;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            transition: transform 0.3s ease;
            position: relative;
            overflow: hidden;
        }
        .tank-card:hover {
            transform: translateY(-5px);
        }
        .tank-visual {
            width: 80px;
            height: 120px;
            border: 3px solid #ddd;
            border-radius: 8px;
            position: relative;
            background: #f8f9fa;
            margin: 0 auto 1rem;
            overflow: hidden;
            z-index: 1;
        }
        .liquid {
            position: absolute;
            bottom: 0;
            left: 0;
            width: 100%;
            background: var(--primary);
            transition: height 1.5s cubic-bezier(0.4, 0, 0.2, 1);
            opacity: 0.8;
        }
        .liquid::after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 5px;
            background: rgba(255,255,255,0.4);
        }
        .tank-info h5 {
            font-weight: 700;
            margin-bottom: 0.2rem;
        }
        .product-badge {
            font-size: 0.8rem;
            padding: 0.3rem 0.8rem;
            border-radius: 20px;
            color: white;
            display: inline-block;
            margin-bottom: 1rem;
        }
        .bg-diesel { background: #ffbe0b; color: #000; } /* Yellow/Orange */
        .bg-petrol { background: #ef233c; } /* Red */
        .bg-gas { background: #3a86ff; } /* Blue */
        
        .variance-alert {
            font-size: 0.8rem;
            padding: 5px;
            border-radius: 5px;
            background: #ffe5e5;
            color: #d00000;
            margin-top: 10px;
            display: block;
            text-align: center;
        }
    </style>
</head>
<body>

<div class="container py-5">
    <div class="d-flex justify-content-between align-items-center mb-5">
        <div>
            <h1 class="fw-bold fs-2" style="color: var(--primary);">إدارة المخزون</h1>
            <p class="text-muted">مراقبة مستويات الوقود والمعايرة</p>
        </div>
        <div>
            <a href="<?= BASE_URL ?>/" class="btn btn-outline-secondary me-2">
                <i class="fas fa-home"></i> الرئيسية
            </a>
            <a href="<?= BASE_URL ?>/tanks/calibration" class="btn btn-primary me-2">
                <i class="fas fa-ruler-vertical"></i> تسجيل معايرة
            </a>
            <a href="<?= BASE_URL ?>/tanks/create" class="btn btn-success">
                <i class="fas fa-plus-circle"></i> إضافة بئر جديد
            </a>
        </div>
    </div>

    <div class="row">
        <?php foreach ($tanks as $tank): 
            $percent = ($tank['capacity_liters'] > 0) ? ($tank['current_volume'] / $tank['capacity_liters']) * 100 : 0;
            $percent = min(100, max(0, $percent)); // Clamp
            
            $bgClass = 'bg-secondary';
            if ($tank['product_type'] === 'Diesel') $bgClass = 'bg-diesel';
            if ($tank['product_type'] === 'Petrol') $bgClass = 'bg-petrol';
            if ($tank['product_type'] === 'Gas') $bgClass = 'bg-gas';
        ?>
        <div class="col-md-6 col-lg-3 mb-4">
            <div class="tank-card text-center">
                <span class="product-badge <?= $bgClass ?>"><?= htmlspecialchars($tank['product_type']) ?></span>
                
                <div class="tank-visual">
                    <div class="liquid" style="height: <?= $percent ?>%; background-color: <?php 
                        if ($tank['product_type'] == 'Diesel') echo '#ffbe0b';
                        if ($tank['product_type'] == 'Petrol') echo '#ef233c'; 
                        if ($tank['product_type'] == 'Gas') echo '#3a86ff';
                    ?>"></div>
                </div>

                <h5><?= htmlspecialchars($tank['name']) ?></h5>
                <h3 class="fw-bold my-2" dir="ltr"><?= number_format($tank['current_volume'], 0) ?> <small class="fs-6 text-muted">Liters</small></h3>
                <p class="text-muted small">Max: <?= number_format($tank['capacity_liters']) ?> L</p>
                
                <hr>
                <div class="d-flex justify-content-around">
                    <button class="btn btn-sm btn-outline-primary" title="Edit"><i class="fas fa-edit"></i></button>
                    <button class="btn btn-sm btn-outline-info" title="History"><i class="fas fa-history"></i></button>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>

</body>
</html>
