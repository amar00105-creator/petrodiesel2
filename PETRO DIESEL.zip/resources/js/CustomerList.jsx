import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Card, Title, Text, TextInput, Badge, Button } from '@tremor/react';
import AddCustomerModal from './AddCustomerModal';
import EditCustomerModal from './EditCustomerModal';

import DeleteConfirmationModal from './DeleteConfirmationModal';
import { toast } from 'sonner';
import { Search, Plus, Phone, MapPin, User, Edit, Trash2 } from 'lucide-react';

export default function CustomerList({ customers = [], onUpdate }) {
    const [search, setSearch] = useState('');
    const [isAddModalOpen, setIsAddModalOpen] = useState(false);
    const [isEditModalOpen, setIsEditModalOpen] = useState(false);
    const [editingCustomer, setEditingCustomer] = useState(null);

    const handleEdit = (customer) => {
        setEditingCustomer(customer);
        setIsEditModalOpen(true);
    };

    // Delete Modal State
    const [deleteModalOpen, setDeleteModalOpen] = useState(false);
    const [itemToDelete, setItemToDelete] = useState(null);
    const [isDeleting, setIsDeleting] = useState(false);

    const openDeleteModal = (customer) => {
        setItemToDelete(customer);
        setDeleteModalOpen(true);
    };

    const confirmDelete = async () => {
        if (!itemToDelete) return;
        setIsDeleting(true);

        const form = new FormData();
        form.append('id', itemToDelete.id);

        try {
            // Using HR Unified API
            const response = await fetch('/PETRODIESEL2/public/hr/api?entity=customer&action=delete', {
                method: 'POST',
                body: form
            });
            const data = await response.json();

            if (data.success) {
                toast.success('تم حذف العميل بنجاح');
                if (onUpdate) {
                    onUpdate(customers.filter(c => c.id !== itemToDelete.id));
                } else {
                    window.location.reload();
                }
            } else {
                toast.error(data.message || 'فشل الحذف');
            }
        } catch (error) {
            toast.error('خطأ في الاتصال');
        } finally {
            setIsDeleting(false);
            setDeleteModalOpen(false);
            setItemToDelete(null);
        }
    };

    const handleAddSuccess = (newCustomer) => {
        if (onUpdate) {
            // Add new customer to the list
            onUpdate([...customers, newCustomer]);
        } else {
            window.location.reload();
        }
    };
    
    const handleEditSuccess = (updatedCustomer) => {
        if (onUpdate) {
            // Update the specific customer in the list
            onUpdate(customers.map(c => c.id === updatedCustomer.id ? { ...c, ...updatedCustomer } : c));
        } else {
            window.location.reload();
        }
    }

    const filteredCustomers = (customers || []).filter(c => 
        c.name.toLowerCase().includes(search.toLowerCase()) || 
        (c.phone && c.phone.includes(search))
    );

    return (
        <motion.div 
            initial={{ opacity: 0 }} animate={{ opacity: 1 }}
            className="p-6 max-w-[1800px] mx-auto space-y-6"
        >
            <DeleteConfirmationModal
                isOpen={deleteModalOpen}
                onClose={() => setDeleteModalOpen(false)}
                onConfirm={confirmDelete}
                title="تحذير: حذف عميل"
                message={`سيتم حذف العميل "${itemToDelete?.name}". هل أنت متأكد؟ لا يمكن التراجع عن هذا الإجراء.`}
                isDeleting={isDeleting}
            />
            {/* Header */}
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <div>
                    <Title className="text-2xl font-bold text-navy-900 font-cairo">قائمة العملاء</Title>
                    <Text className="text-slate-500">إدارة سجلات العملاء والديون</Text>
                </div>
                <Button icon={Plus} onClick={() => setIsAddModalOpen(true)} className="rounded-xl font-bold bg-navy-900 hover:bg-navy-800 border-none">إضافة عميل</Button>
            </div>

            {/* Filters */}
            <Card className="rounded-2xl shadow-sm ring-1 ring-slate-200">
                <div className="relative max-w-md">
                    <Search className="absolute right-3 top-3 text-slate-400 w-5 h-5"/>
                    <TextInput 
                        placeholder="بحث عن عميل..." 
                        className="pl-4 pr-10 py-2 rounded-xl"
                        value={search}
                        onChange={(e) => setSearch(e.target.value)}
                    />
                </div>
            </Card>

            {/* Table */}
            <Card className="rounded-2xl shadow-lg ring-1 ring-slate-200 overflow-hidden p-0">
                <div className="overflow-x-auto">
                    <table className="w-full text-right">
                        <thead className="bg-slate-50 border-b border-slate-200">
                            <tr>
                                <th className="p-4 text-sm font-bold text-slate-600">اسم العميل</th>
                                <th className="p-4 text-sm font-bold text-slate-600">رقم الهاتف</th>
                                <th className="p-4 text-sm font-bold text-slate-600">العنوان</th>
                                <th className="p-4 text-sm font-bold text-slate-600">الملاحظات</th>
                                <th className="p-4 text-sm font-bold text-slate-600 text-center">إجراءات</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                            {filteredCustomers.map((cust) => (
                                <tr key={cust.id} className="hover:bg-blue-50/30 transition-colors group">
                                    <td className="p-4">
                                        <div className="flex items-center gap-3">
                                            <div className="p-2 bg-indigo-100 rounded-lg text-indigo-600">
                                                <User className="w-5 h-5" />
                                            </div>
                                            <span className="font-bold text-navy-900">{cust.name}</span>
                                        </div>
                                    </td>
                                    <td className="p-4 font-mono text-slate-600">
                                        <div className="flex items-center gap-2">
                                            <Phone className="w-3 h-3 text-slate-400"/> {cust.phone || '-'}
                                        </div>
                                    </td>
                                    <td className="p-4 text-sm text-slate-500">
                                        <div className="flex items-center gap-2">
                                            <MapPin className="w-3 h-3 text-slate-400"/> {cust.address || '-'}
                                        </div>
                                    </td>
                                    <td className="p-4 max-w-xs truncate text-slate-500">
                                        {cust.notes || '-'}
                                    </td>
                                    <td className="p-4">
                                        <div className="flex justify-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                                            <button onClick={() => handleEdit(cust)} className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"><Edit className="w-4 h-4"/></button>
                                            <button onClick={() => openDeleteModal(cust)} className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"><Trash2 className="w-4 h-4"/></button>
                                        </div>
                                    </td>
                                </tr>
                            ))}
                            {filteredCustomers.length === 0 && (
                                <tr>
                                    <td colSpan="5" className="p-8 text-center text-slate-500">لا يوجد عملاء مطابقين</td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </Card>

            <AddCustomerModal 
                isOpen={isAddModalOpen} 
                onClose={() => setIsAddModalOpen(false)}
                onSuccess={handleAddSuccess}
            />

            <EditCustomerModal 
                isOpen={isEditModalOpen} 
                onClose={() => setIsEditModalOpen(false)}
                customer={editingCustomer}
                onSuccess={() => window.location.reload()} 
            />
        </motion.div>
    );
}
