<!DOCTYPE html>
<html lang="ar" dir="rtl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PetroDiesel ERP</title>
    <!-- Bootstrap RTL -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f4f6f9;
        }

        .sidebar {
            min-height: 100vh;
            background-color: #343a40;
            color: white;
        }

        .sidebar a {
            color: #c2c7d0;
            text-decoration: none;
            padding: 10px 15px;
            display: block;
        }

        .sidebar a:hover,
        .sidebar a.active {
            background-color: #007bff;
            color: white;
        }

        .content-wrapper {
            padding: 20px;
        }
    </style>
</head>

<body>

    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-2 p-0 sidebar">
                <h4 class="text-center py-3 border-bottom border-secondary">PetroDiesel</h4>
                <nav class="mt-2">
                    <a href="<?php echo BASE_URL; ?>/"
                        class="<?php echo $_SERVER['REQUEST_URI'] == '/PETRODIESEL/public/' ? 'active' : ''; ?>">
                        <i class="fas fa-tachometer-alt me-2"></i> لوحة التحكم
                    </a>

                    <?php if (App\Helpers\AuthHelper::can('stations_manage')): ?>
                        <a href="<?php echo BASE_URL; ?>/stations"
                            class="<?php echo strpos($_SERVER['REQUEST_URI'], '/stations') !== false ? 'active' : ''; ?>">
                            <i class="fas fa-gas-pump me-2"></i> المحطات
                        </a>
                    <?php endif; ?>

                    <?php if (App\Helpers\AuthHelper::can('tanks_view')): ?>
                    <a href="<?php echo BASE_URL; ?>/tanks">
                        <i class="fas fa-database me-2"></i> المخزون (الخزانات)
                    </a>
                    <?php endif; ?>

                    <?php if (App\Helpers\AuthHelper::can('sales_view')): ?>
                    <a href="<?php echo BASE_URL; ?>/sales">
                        <i class="fas fa-cart-shopping me-2"></i> المبيعات
                    </a>
                    <?php endif; ?>

                    <?php if (App\Helpers\AuthHelper::can('purchases_view')): ?>
                    <a href="<?php echo BASE_URL; ?>/purchases">
                        <i class="fas fa-truck me-2"></i> المشتروات
                    </a>
                    <?php endif; ?>

                    <?php if (App\Helpers\AuthHelper::can('expenses_view') || App\Helpers\AuthHelper::can('finance_view')): ?>
                    <a href="<?php echo BASE_URL; ?>/expenses">
                        <i class="fas fa-money-bill-wave me-2"></i> المصروفات
                    </a>
                    <?php endif; ?>

                    <?php if (App\Helpers\AuthHelper::can('finance_view')): ?>
                    <a href="<?php echo BASE_URL; ?>/accounting">
                        <i class="fas fa-file-invoice-dollar me-2"></i> الحسابات
                    </a>
                    <?php endif; ?>
                    
                    <div class="border-top border-secondary my-2"></div>
                    
                    <?php if (App\Helpers\AuthHelper::can('settings_view')): ?>
                    <a href="<?php echo BASE_URL; ?>/settings"
                        class="<?php echo strpos($_SERVER['REQUEST_URI'], '/settings') !== false ? 'active' : ''; ?>">
                        <i class="fas fa-cogs me-2"></i> الإعدادات
                    </a>
                    <?php endif; ?>

                    <a href="<?php echo BASE_URL; ?>/logout" class="text-danger mt-3 border-top border-secondary">
                        <i class="fas fa-sign-out-alt me-2"></i> تسجيل خروج
                    </a>
                </nav>
            </div>

            <!-- Main Content -->
            <div class="col-md-10 content-wrapper">
                <!-- Topbar -->
                <nav class="navbar navbar-expand-lg navbar-light bg-white border-bottom mb-4 rounded shadow-sm">
                    <div class="container-fluid">
                        <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                            data-bs-target="#navbarContent">
                            <span class="navbar-toggler-icon"></span>
                        </button>
                        <div class="collapse navbar-collapse" id="navbarContent">
                            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                                <li class="nav-item">
                                    <span class="nav-link fw-bold">
                                        <?php echo isset($_SESSION['user_name']) ? "مرحباً، " . htmlspecialchars($_SESSION['user_name']) : ''; ?>
                                    </span>
                                </li>
                            </ul>
                        </div>
                    </div>
                </nav>

                <!-- Page Content Injection -->
                <?php include $child_view; ?>

            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>