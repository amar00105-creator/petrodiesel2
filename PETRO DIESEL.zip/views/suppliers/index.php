<?php
// views/suppliers/index.php
// React Mounting Point for Partners (Customers & Suppliers)
?>

<div id="root"
    data-page="supplier-list"
    data-suppliers='<?= json_encode($suppliers ?? []) ?>'
    data-user='<?= json_encode($user ?? []) ?>'
    data-stats='<?= json_encode($stats ?? []) ?>'
    data-all-stations='<?= json_encode($allStations ?? []) ?>'
    class="h-full w-full">
    <!-- React loads here -->
    <div class="flex items-center justify-center min-h-screen">
        <div class="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
    </div>
</div>