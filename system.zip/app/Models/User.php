<?php

namespace App\Models;

use App\Core\Model;
use PDO;

class User extends Model
{

    public function findByEmail($email)
    {
        $stmt = $this->db->prepare("SELECT * FROM users WHERE email = :email LIMIT 1");
        $stmt->bindParam(':email', $email);
        $stmt->execute();
        return $stmt->fetch();
    }

    public function create($data)
    {
        $sql = "INSERT INTO users (station_id, name, email, password_hash, google_id, role, status) 
                VALUES (:station_id, :name, :email, :password_hash, :google_id, :role, :status)";

        $stmt = $this->db->prepare($sql);

        $stmt->execute([
            ':station_id' => $data['station_id'] ?? null,
            ':name' => $data['name'],
            ':email' => $data['email'],
            ':password_hash' => $data['password_hash'] ?? null, // Can be null if using Google only
            ':google_id' => $data['google_id'] ?? null,
            ':role' => $data['role'] ?? 'viewer',
            ':status' => 'active'
        ]);

        return $this->db->lastInsertId();
    }
}
