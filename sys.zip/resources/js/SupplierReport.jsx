import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Calendar, Search, Filter, Fuel, Banknote, Truck } from 'lucide-react';
import { Card, Title, Text, Metric, Select, SelectItem, Grid } from '@tremor/react';
import { toast } from 'sonner';

export default function SupplierReport({ stationId }) {
    const [loading, setLoading] = useState(false);
    const [suppliers, setSuppliers] = useState([]);
    const [data, setData] = useState(null);
    const [filters, setFilters] = useState({
        supplier_id: '',
        period: 'month', // day, week, month, year, custom
        start_date: new Date().toISOString().split('T')[0],
        end_date: new Date().toISOString().split('T')[0]
    });

    // --- Inital Load: Get Suppliers ---
    useEffect(() => {
        fetchSuppliers();
    }, []);

    const fetchSuppliers = async () => {
        try {
            const response = await fetch(`${window.BASE_URL}/reports?action=get_sources&type=supplier`);
            const result = await response.json();
            if (result.suppliers) {
                setSuppliers(result.suppliers);
            }
        } catch (error) {
            console.error("Failed to fetch suppliers", error);
        }
    };

    // --- Main Data Fetch ---
    const fetchReport = async () => {
        if (!filters.supplier_id) return;
        
        setLoading(true); // Don't wipe data immediately to keep UI stable
        try {
            const query = new URLSearchParams({
                action: 'get_supplier_report',
                station_id: stationId,
                ...filters
            }).toString();

            const response = await fetch(`${window.BASE_URL}/reports?${query}`, {
                headers: { 'X-Requested-With': 'XMLHttpRequest' }
            });
            const result = await response.json();
            
            if (result.success) {
                setData(result.data); 
            } else {
                toast.error(result.message || 'فشل تحميل التقرير');
            }
        } catch (error) {
            console.error(error);
            toast.error('حدث خطأ أثناء تحميل البيانات');
        } finally {
            setLoading(false);
        }
    };

    // Auto-fetch when filters change
    useEffect(() => {
        if (filters.supplier_id) {
            fetchReport();
        }
    }, [filters.supplier_id, filters.period, filters.start_date, filters.end_date]);


    // --- Handlers ---
    const handlePeriodChange = (val) => {
        const now = new Date();
        let start = new Date();
        const end = new Date();

        if (val === 'day') {
            // Today
        } else if (val === 'week') {
            start.setDate(now.getDate() - 7);
        } else if (val === 'month') {
            start.setDate(1); // First of month
        } else if (val === 'year') {
            start.setMonth(0, 1); // Jan 1
        }
        
        setFilters(prev => ({
            ...prev,
            period: val,
            start_date: start.toISOString().split('T')[0],
            end_date: end.toISOString().split('T')[0]
        }));
    };

    // --- Helpers ---
    const formatCurrency = (val) => formatNumber(val) + ' SDG';
    const formatNumber = (val) => parseFloat(val || 0).toLocaleString('en-US');

    const periods = [
        { id: 'day', label: 'اليوم' },
        { id: 'week', label: 'أسبوع' },
        { id: 'month', label: 'شهر' },
        { id: 'year', label: 'سنة' },
        { id: 'custom', label: 'مخصص' },
    ];

    return (
        <div className="space-y-6 animate-fade-in pb-10">
            {/* Header / Filters Bar */}
            <Card className="bg-white/80 backdrop-blur-md p-4 shadow-sm rounded-2xl border border-slate-100/50 sticky top-0 z-20">
                <div className="flex flex-col md:flex-row items-center justify-between gap-4">
                    
                    {/* Right Side: Period Buttons */}
                    <div className="flex flex-wrap items-center gap-2 justify-center md:justify-start w-full md:w-auto order-2 md:order-1">
                        <div className="bg-slate-100 p-1 rounded-xl flex gap-1">
                            {periods.map((p) => (
                                <button
                                    key={p.id}
                                    onClick={() => handlePeriodChange(p.id)}
                                    className={`px-4 py-1.5 rounded-lg text-sm font-bold transition-all duration-300 ${
                                        filters.period === p.id 
                                        ? 'bg-white text-blue-600 shadow-sm scale-105' 
                                        : 'text-slate-500 hover:text-slate-700 hover:bg-slate-200/50'
                                    }`}
                                >
                                    {p.label}
                                </button>
                            ))}
                        </div>
                    </div>

                    {/* Left Side: Supplier Dropdown & Title */}
                    <div className="flex flex-col md:flex-row items-center gap-4 w-full md:w-auto order-1 md:order-2">
                        
                         {/* Report Title */}
                         <div className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-blue-600 to-cyan-500 rounded-xl text-white shadow-lg shadow-cyan-200">
                            <Truck className="w-5 h-5" />
                            <span className="font-bold text-lg whitespace-nowrap">كشف حساب مورد</span>
                        </div>

                        {/* Supplier Selector */}
                        <div className="w-full md:w-64">
                            <Select 
                                value={filters.supplier_id} 
                                onValueChange={(val) => setFilters(prev => ({ ...prev, supplier_id: val }))}
                                placeholder="اختر المورد..."
                                icon={Search}
                                className="font-bold"
                            >
                                {suppliers.map(s => (
                                    <SelectItem key={s.id} value={String(s.id)}>
                                        {s.name}
                                    </SelectItem>
                                ))}
                            </Select>
                        </div>
                    </div>

                </div>

                {/* Custom Date Inputs (Conditional) */}
                <AnimatePresence>
                    {filters.period === 'custom' && (
                        <motion.div 
                            initial={{ height: 0, opacity: 0 }}
                            animate={{ height: 'auto', opacity: 1 }}
                            exit={{ height: 0, opacity: 0 }}
                            className="overflow-hidden"
                        >
                            <div className="mt-4 pt-4 border-t border-slate-100 flex items-center justify-start gap-4">
                                <div>
                                    <label className="text-xs font-bold text-slate-400 ml-2">من تاريخ</label>
                                    <input 
                                        type="date" 
                                        value={filters.start_date}
                                        onChange={(e) => setFilters(prev => ({ ...prev, start_date: e.target.value }))}
                                        className="bg-slate-50 border border-slate-200 text-slate-700 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block p-2 outline-none" 
                                    />
                                </div>
                                <div className="flex items-center self-end pb-2">
                                    <span className="text-slate-300">-----</span>
                                </div>
                                <div>
                                    <label className="text-xs font-bold text-slate-400 ml-2">إلى تاريخ</label>
                                    <input 
                                        type="date" 
                                        value={filters.end_date}
                                        onChange={(e) => setFilters(prev => ({ ...prev, end_date: e.target.value }))}
                                        className="bg-slate-50 border border-slate-200 text-slate-700 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block p-2 outline-none" 
                                    />
                                </div>
                            </div>
                        </motion.div>
                    )}
                </AnimatePresence>
            </Card>

            {/* Report Content */}
            {!filters.supplier_id ? (
                <motion.div 
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="text-center py-24 bg-white rounded-3xl border border-slate-100 shadow-sm"
                >
                    <Search className="w-20 h-20 text-slate-200 mx-auto mb-4" />
                    <Title className="text-slate-700 text-xl font-bold">حدد المورد لعرض التقرير</Title>
                    <Text className="text-slate-400">يمكنك اختيار المورد من القائمة أعلاه</Text>
                </motion.div>
            ) : !data && loading ? (
                 <div className="text-center py-24">
                     <div className="animate-spin w-12 h-12 border-4 border-blue-500 border-t-transparent rounded-full mx-auto mb-4 shadow-xl shadow-blue-200"></div>
                     <Text className="text-blue-600 font-bold animate-pulse">جاري جلب البيانات...</Text>
                 </div>
            ) : data ? (
                <>
                    {/* Summary Cards */}
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.1 }}>
                            <Card decoration="top" decorationColor="emerald" className="bg-white hover:shadow-lg transition-shadow">
                                <Text>إجمالي المدفوعات (لنا)</Text>
                                <Metric className="mt-2 text-emerald-600 drop-shadow-sm">{formatCurrency(data.totals.total_paid)}</Metric>
                            </Card>
                        </motion.div>
                        <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.2 }}>
                            <Card decoration="top" decorationColor="blue" className="bg-white hover:shadow-lg transition-shadow">
                                <Text>إجمالي المشتريات (علينا)</Text>
                                <Metric className="mt-2 text-blue-600 drop-shadow-sm">{formatCurrency(data.totals.total_purchased)}</Metric>
                            </Card>
                        </motion.div>
                        <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.3 }}>
                            <Card decoration="top" decorationColor={data.totals.net_balance > 0 ? 'rose' : 'teal'} className="bg-white hover:shadow-lg transition-shadow">
                                <Text>صافي الرصيد النهائي</Text>
                                <Metric className={`mt-2 ${data.totals.net_balance > 0 ? 'text-rose-600' : 'text-teal-600'} drop-shadow-sm`}>
                                    {formatCurrency(data.totals.net_balance)}
                                </Metric>
                                <Text className="text-xs text-slate-400 mt-1">
                                    {data.totals.net_balance > 0 ? 'مبلغ مستحق للمورد' : 'فائض مدفوع'}
                                </Text>
                            </Card>
                        </motion.div>
                    </div>

                    {/* Transactions Table */}
                    <Card className="px-0 py-0 overflow-hidden bg-white shadow-lg rounded-2xl border border-slate-100">
                        <div className="overflow-x-auto min-h-[400px]">
                            {loading && (
                                <div className="absolute inset-0 bg-white/50 backdrop-blur-[1px] z-10 flex items-center justify-center">
                                    <div className="animate-spin w-8 h-8 border-2 border-blue-600 border-t-transparent rounded-full"></div>
                                </div>
                            )}
                            <table className="w-full text-right text-sm">
                                <thead className="bg-slate-50 text-slate-600 font-bold border-b border-slate-200">
                                    <tr>
                                        <th className="p-4 whitespace-nowrap">التاريخ</th>
                                        <th className="p-4 whitespace-nowrap">البيان</th>
                                        <th className="p-4 whitespace-nowrap">التصنيف</th>
                                        <th className="p-4 whitespace-nowrap">الكمية</th>
                                        <th className="p-4 whitespace-nowrap">السعر</th>
                                        <th className="p-4 whitespace-nowrap text-emerald-600">المبلغ (مدفوع)</th>
                                        <th className="p-4 whitespace-nowrap text-blue-600">قيمة الشراء</th>
                                        <th className="p-4 whitespace-nowrap">الإجمالي (تراكمي)</th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-slate-100">
                                    <AnimatePresence>
                                        {data.transactions.length > 0 ? (
                                            data.transactions.map((row, idx) => (
                                                <motion.tr 
                                                    key={idx} 
                                                    initial={{ opacity: 0, y: 10 }}
                                                    animate={{ opacity: 1, y: 0 }}
                                                    transition={{ delay: idx * 0.03 }}
                                                    className="hover:bg-blue-50/50 transition-colors group"
                                                >
                                                    <td className="p-4 whitespace-nowrap text-slate-600 font-mono text-xs">{row.date}</td>
                                                    <td className="p-4">
                                                        <div className="font-bold text-slate-800">{row.statement_title}</div>
                                                        <div className="text-xs text-slate-400 group-hover:text-slate-500 transition-colors">{row.statement_subtitle}</div>
                                                    </td>
                                                    <td className="p-4">
                                                        <span className={`px-2.5 py-1 rounded-full text-xs font-bold flex w-fit items-center gap-1.5 shadow-sm ${
                                                            row.type === 'purchase' 
                                                            ? 'bg-gradient-to-r from-blue-50 to-indigo-50 text-blue-700 border border-blue-100' 
                                                            : 'bg-gradient-to-r from-emerald-50 to-teal-50 text-emerald-700 border border-emerald-100'
                                                        }`}>
                                                            {row.type === 'purchase' ? <Fuel className="w-3.5 h-3.5"/> : <Banknote className="w-3.5 h-3.5"/>}
                                                            {row.category}
                                                        </span>
                                                    </td>
                                                    <td className="p-4 font-mono text-slate-600">
                                                        {row.quantity ? formatNumber(row.quantity) : '-'}
                                                    </td>
                                                    <td className="p-4 font-mono text-slate-400 text-xs">
                                                        {row.price ? formatNumber(row.price) : '-'}
                                                    </td>
                                                    <td className="p-4 font-mono font-bold text-emerald-600 bg-emerald-50/30">
                                                        {row.amount_paid ? formatCurrency(row.amount_paid) : '-'}
                                                    </td>
                                                    <td className="p-4 font-mono font-bold text-blue-600 bg-blue-50/30">
                                                        {row.purchase_value ? formatCurrency(row.purchase_value) : '-'}
                                                    </td>
                                                    <td className="p-4 font-bold text-slate-800" dir="ltr">
                                                        <span className={row.running_balance > 0 ? 'text-rose-600' : 'text-teal-600'}>
                                                            {formatCurrency(row.running_balance)}
                                                        </span>
                                                    </td>
                                                </motion.tr>
                                            ))
                                        ) : (
                                            <tr>
                                                <td colSpan="8" className="p-12 text-center text-slate-400">
                                                    لا توجد حركات في هذه الفترة
                                                </td>
                                            </tr>
                                        )}
                                    </AnimatePresence>
                                </tbody>
                                <tfoot className="bg-slate-50 font-bold border-t-2 border-slate-200">
                                    <tr>
                                        <td colSpan="5" className="p-4 text-left text-slate-600">المجاميع النهائية للفترة:</td>
                                        <td className="p-4 text-emerald-700 bg-emerald-50">{formatCurrency(data.totals.total_paid)}</td>
                                        <td className="p-4 text-blue-700 bg-blue-50">{formatCurrency(data.totals.total_purchased)}</td>
                                        <td className="p-4 text-slate-900 bg-slate-100" dir="ltr">{formatCurrency(data.totals.net_balance)}</td>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </Card>
                </>
            ) : null}
        </div>
    );
}
