<?php
// Detect environment based on host
$isLocal = (php_sapi_name() === 'cli') || in_array($_SERVER['HTTP_HOST'] ?? '', ['localhost', '127.0.0.1', '::1']);

if ($isLocal) {
    return [
        'host' => 'localhost',
        'db_name' => 'petrodiesel_db',
        'username' => 'root',
        'password' => ''
    ];
} else {
    // LIVE SERVER CREDENTIALS
    // PLEASE UPDATE THESE VALUES
    return [
        'host' => 'localhost',
        'db_name' => 'petrnugv_petrodiesel-database',
        'username' => 'petrnugv_petrodiesel',
        'password' => 'Petro@00105'
    ];
}
