import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Card, Title, Text, TextInput, Select, SelectItem, Badge, Button } from '@tremor/react';
import { Search, Download, FileText, Trash2, Edit, ChevronLeft, ChevronRight, Truck, Calendar, Building2, CheckCircle, Clock, Printer, Activity, Droplet } from 'lucide-react';
import { toast } from 'sonner';
import DeleteConfirmationModal from './DeleteConfirmationModal';
import DischargeModal from './DischargeModal';

export default function PurchaseList({ purchases = [], tanks = [] }) {
    const [search, setSearch] = useState('');
    const [filterSupplier, setFilterSupplier] = useState('');
    const [filterStatus, setFilterStatus] = useState('');
    const [dateFrom, setDateFrom] = useState('');
    const [dateTo, setDateTo] = useState('');
    const [showExportMenu, setShowExportMenu] = useState(false);

    // Filter Logic
    const filteredPurchases = (purchases || []).filter(p => {
        const matchesSearch = (p.invoice_number?.toLowerCase().includes(search.toLowerCase()) || p.supplier_name?.toLowerCase().includes(search.toLowerCase()));
        const matchesSupplier = filterSupplier ? p.supplier_name === filterSupplier : true;
        
        // Status Mapping: 'ordered'/'pending' -> 'Shipping' (Orange), 'completed' -> 'Discharged' (Green)
        // Adjust filter to match visually shown status if needed, or map backend status
        const matchesStatus = filterStatus ? p.status === filterStatus : true;

        const purchaseDate = new Date(p.created_at || p.date).setHours(0,0,0,0);
        const from = dateFrom ? new Date(dateFrom).setHours(0,0,0,0) : null;
        const to = dateTo ? new Date(dateTo).setHours(0,0,0,0) : null;
        
        const matchesDate = (!from || purchaseDate >= from) && (!to || purchaseDate <= to);

        return matchesSearch && matchesSupplier && matchesStatus && matchesDate;
    });

    // Delete Modal State
    const [deleteModalOpen, setDeleteModalOpen] = useState(false);
    const [itemToDelete, setItemToDelete] = useState(null);
    const [isDeleting, setIsDeleting] = useState(false);

    // Discharge Modal State
    const [dischargeModalOpen, setDischargeModalOpen] = useState(false);

    const openDeleteModal = (item) => {
        setItemToDelete(item);
        setDeleteModalOpen(true);
    };

    const confirmDelete = async () => {
        if (!itemToDelete) return;
        setIsDeleting(true);
        
        const form = new FormData();
        form.append('id', itemToDelete.id);

        try {
            const response = await fetch('/PETRODIESEL2/public/purchases/delete_ajax', { method: 'POST', body: form });
            const text = await response.text();
            let data;
            try { data = JSON.parse(text); } catch { throw new Error("Invalid Server Response"); }

            if (data.success) {
                toast.success('تم حذف الفاتورة بنجاح');
                setTimeout(() => window.location.reload(), 1000);
            } else {
                toast.error(data.message || 'فشل عملية الحذف');
            }
        } catch (e) {
            toast.error('خطأ في الاتصال بالخادم');
        } finally {
            setIsDeleting(false);
            setDeleteModalOpen(false);
            setItemToDelete(null);
        }
    };

    // Export Logic
    const handleExport = (type) => {
        if (type === 'excel') {
            // Simple CSV Export
            const headers = ['رقم الفاتورة', 'المورد', 'التاريخ', 'الكمية', 'الاجمالي', 'الحالة'];
            const csvContent = [
                headers.join(','),
                ...filteredPurchases.map(p => [
                    p.invoice_number,
                    p.supplier_name,
                    p.created_at,
                    p.volume_ordered,
                    p.total_cost,
                    p.status
                ].join(','))
            ].join('\n');
            const blob = new Blob(["\uFEFF" + csvContent], { type: 'text/csv;charset=utf-8;' });
            const url = URL.createObjectURL(blob);
            const link = document.createElement('a');
            link.href = url;
            link.download = `purchases_${new Date().toISOString().slice(0,10)}.csv`;
            link.click();
        } else if (type === 'pdf') {
            window.print();
        }
        setShowExportMenu(false);
    };

    const handlePrint = () => {
        window.print();
    };

    // Helper: Delay Check for "Heartbeat"
    const isDelayed = (dateStr) => {
        if (!dateStr) return false;
        const diffTime = Math.abs(new Date() - new Date(dateStr));
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)); 
        return diffDays > 10;
    };

    return (
        <motion.div 
            initial={{ opacity: 0 }} animate={{ opacity: 1 }}
            className="p-6 max-w-[1800px] mx-auto space-y-6 print:p-0 print:max-w-none"
        >
            {/* Delete Modal */}
            <DeleteConfirmationModal 
                isOpen={deleteModalOpen} 
                onClose={() => setDeleteModalOpen(false)}
                onConfirm={confirmDelete}
                title="تحذير: حذف فاتورة شراء"
                message={`سيتم حذف فاتورة الشراء رقم ${itemToDelete?.invoice_number}. هل أنت متأكد؟`}
                isDeleting={isDeleting}
            />

            {/* Header - Cleaned up */}
            <div className="flex flex-col md:flex-row justify-end items-start md:items-center gap-4 print:hidden">
                
                <div className="flex flex-wrap gap-2 items-center">
                    {/* Export Dropdown */}
                    <div className="relative">
                        <button 
                            onClick={() => setShowExportMenu(!showExportMenu)}
                            className="flex items-center gap-2 px-4 py-2.5 bg-white border border-slate-200 text-slate-700 rounded-xl font-bold hover:bg-slate-50 transition-colors"
                        >
                            <Download className="w-4 h-4" /> تصدير
                        </button>
                        {showExportMenu && (
                            <div className="absolute top-full left-0 mt-2 w-32 bg-white rounded-xl shadow-lg border border-slate-100 py-2 z-50">
                                <button onClick={() => handleExport('excel')} className="w-full text-right px-4 py-2 hover:bg-slate-50 text-sm font-medium">Excel (CSV)</button>
                                <button onClick={() => handleExport('pdf')} className="w-full text-right px-4 py-2 hover:bg-slate-50 text-sm font-medium">PDF</button>
                            </div>
                        )}
                    </div>

                    <button 
                        onClick={handlePrint}
                        className="flex items-center gap-2 px-4 py-2.5 bg-white border border-slate-200 text-slate-700 rounded-xl font-bold hover:bg-slate-50 transition-colors"
                    >
                        <Printer className="w-4 h-4" /> طباعة
                    </button>

                    {/* New Invoice - Using Anchor for Speed */}
                    <a 
                        href="/PETRODIESEL2/public/purchases/create" 
                        className="flex items-center gap-2 px-6 py-2.5 bg-navy-900 text-white rounded-xl font-bold hover:bg-navy-800 transition-colors shadow-lg shadow-navy-900/20"
                    >
                         <FileText className="w-5 h-5" /> فاتورة جديدة
                    </a>
                </div>
            </div>

            {/* Filters Bar */}
            <Card className="rounded-2xl shadow-sm ring-1 ring-slate-200 print:hidden">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                    <div className="relative">
                        <Search className="absolute right-3 top-3 text-slate-400 w-5 h-5"/>
                        <TextInput 
                            placeholder="بحث برقم الفاتورة..." 
                            className="pl-4 pr-10 py-2.5 rounded-xl border-slate-200"
                            value={search}
                            onChange={(e) => setSearch(e.target.value)}
                        />
                    </div>
                    <Select placeholder="كل الموردين" value={filterSupplier} onValueChange={setFilterSupplier} className="rounded-xl">
                        {/* Ideally distinct suppliers from data */}
                        <SelectItem value="Saudi Aramco" icon={Building2}>Saudi Aramco</SelectItem>
                        <SelectItem value="National Fuel Co." icon={Building2}>National Fuel Co.</SelectItem>
                    </Select>
                     <Select placeholder="حالة الشحن" value={filterStatus} onValueChange={setFilterStatus} className="rounded-xl">
                        <SelectItem value="completed" icon={CheckCircle}>تم التفريغ (Discharged)</SelectItem>
                        <SelectItem value="ordered" icon={Clock}>شاحن (Shipping)</SelectItem>
                    </Select>
                    
                    {/* Date Range */}
                    <div className="flex items-center gap-2">
                        <div className="relative w-full">
                            <span className="absolute -top-2 right-2 bg-white px-1 text-[10px] text-slate-400">من</span>
                            <input 
                                type="date" 
                                value={dateFrom}
                                onChange={(e) => setDateFrom(e.target.value)}
                                className="w-full pl-2 pr-2 py-2.5 rounded-xl border border-slate-200 text-sm focus:ring-2 focus:ring-blue-100 outline-none" 
                            />
                        </div>
                        <div className="relative w-full">
                            <span className="absolute -top-2 right-2 bg-white px-1 text-[10px] text-slate-400">إلى</span>
                            <input 
                                type="date" 
                                value={dateTo}
                                onChange={(e) => setDateTo(e.target.value)}
                                className="w-full pl-2 pr-2 py-2.5 rounded-xl border border-slate-200 text-sm focus:ring-2 focus:ring-blue-100 outline-none" 
                            />
                        </div>
                    </div>
                </div>
            </Card>

            {/* Table */}
            <Card className="rounded-2xl shadow-lg ring-1 ring-slate-200 overflow-hidden p-0 print:shadow-none print:ring-0">
                <div className="overflow-x-auto">
                    <table className="w-full text-right">
                        <thead className="bg-slate-50 border-b border-slate-200 print:bg-white">
                            <tr>
                                <th className="p-4 text-sm font-bold text-slate-600">رقم الفاتورة</th>
                                <th className="p-4 text-sm font-bold text-slate-600">التاريخ</th>
                                <th className="p-4 text-sm font-bold text-slate-600">المورد</th>
                                <th className="p-4 text-sm font-bold text-slate-600">الكمية (L)</th>
                                <th className="p-4 text-sm font-bold text-slate-600">الاجمالي (SAR)</th>
                                <th className="p-4 text-sm font-bold text-slate-600">الحالة</th>
                                <th className="p-4 text-sm font-bold text-slate-600 text-center print:hidden">إجراءات</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                            {filteredPurchases.map((item) => {
                                const isDelayedShipping = (item.status === 'ordered' || item.status === 'pending') && isDelayed(item.created_at);
                                return (
                                    <tr key={item.id} className="hover:bg-blue-50/30 transition-colors group">
                                        <td className="p-4 font-mono font-bold text-navy-900">#{item.invoice_number}</td>
                                        <td className="p-4 text-sm text-slate-600">{item.created_at ? new Date(item.created_at).toLocaleDateString('en-GB') : '-'}</td>
                                        <td className="p-4">
                                            <div className="flex items-center gap-2">
                                                <Building2 className="w-4 h-4 text-slate-400"/>
                                                <span className="font-bold text-slate-700">{item.supplier_name || 'غير محدد'}</span>
                                            </div>
                                        </td>
                                        <td className="p-4 font-mono">{Number(item.volume_received || item.volume_ordered || 0).toLocaleString()}</td>
                                        <td className="p-4 font-mono font-bold text-emerald-600">{Number(item.total_cost || 0).toLocaleString()}</td>
                                        <td className="p-4">
                                            {item.status === 'completed' ? (
                                                <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold bg-green-100 text-green-700 border border-green-200">
                                                    <CheckCircle className="w-3.5 h-3.5" /> تم التفريغ
                                                </span>
                                            ) : (
                                                <span className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold border ${
                                                    isDelayedShipping 
                                                    ? 'bg-red-50 text-red-600 border-red-200 animate-pulse' 
                                                    : 'bg-orange-100 text-orange-700 border-orange-200'
                                                }`}>
                                                    {isDelayedShipping ? <Activity className="w-3.5 h-3.5 animate-bounce" /> : <Truck className="w-3.5 h-3.5" />}
                                                    {isDelayedShipping ? 'شاحن (تأخير)' : 'شاحن'}
                                                </span>
                                            )}
                                        </td>
                                        <td className="p-4 print:hidden">
                                            <div className="flex justify-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                                                {/* Discharge Button for non-completed items */}
                                                {item.status !== 'completed' && (
                                                    <button 
                                                        onClick={() => setDischargeModalOpen(true)} // Currently generic, modal fetches list. Or we can select specific? 
                                                        // DischargeModal logic handles fetching pending list. 
                                                        // Ideally we could pass the specific item to pre-select it?
                                                        // The DischargeModal fetches 'getPending'. 
                                                        // If we want to open it for THIS item, we might need to modify DischargeModal to accept 'initialSelection'
                                                        // For now, just opening it allows user to select from list. 
                                                        title="تفريغ الشحنة"
                                                        className="p-2 text-emerald-600 hover:bg-emerald-50 rounded-lg transition-colors"
                                                    >
                                                        <Droplet className="w-4 h-4"/>
                                                    </button>
                                                )}

                                                <a href={`/PETRODIESEL2/public/purchases/edit?id=${item.id}`} className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"><Edit className="w-4 h-4"/></a>
                                                <button onClick={() => openDeleteModal(item)} className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"><Trash2 className="w-4 h-4"/></button>
                                            </div>
                                        </td>
                                    </tr>
                                );
                            })}
                        </tbody>
                    </table>
                </div>

                {/* Pagination */}
                <div className="p-4 border-t border-slate-100 flex justify-between items-center bg-slate-50/50 print:hidden">
                    <Text className="text-sm text-slate-500">عرض {filteredPurchases.length} فاتورة</Text>
                    <div className="flex gap-2">
                        <button className="p-2 border border-slate-200 rounded-lg hover:bg-white disabled:opacity-50"><ChevronRight className="w-4 h-4"/></button>
                        <button className="p-2 border border-slate-200 rounded-lg hover:bg-white"><ChevronLeft className="w-4 h-4"/></button>
                    </div>
                </div>

                <DischargeModal 
                    isOpen={dischargeModalOpen} 
                    onClose={() => setDischargeModalOpen(false)}
                    tanks={tanks}
                />
            </Card>
        </motion.div>
    );
}
