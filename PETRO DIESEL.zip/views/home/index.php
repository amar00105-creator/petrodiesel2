<?php
// views/home/index.php
?>
<!-- React Root -->
<div id="root"
    data-page="dashboard"
    data-data='<?= json_encode($data ?? []) ?>'
    data-user='<?= json_encode($user ?? []) ?>'
    data-all-stations='<?= json_encode($allStations ?? []) ?>'
    data-stats='<?= json_encode(['activeUsers' => $activeUsersCount ?? 0]) ?>'
    class="h-full w-full"></div>

<!-- React & Vite Integration -->
<?= \App\Helpers\ViteHelper::load('resources/js/main.jsx') ?>